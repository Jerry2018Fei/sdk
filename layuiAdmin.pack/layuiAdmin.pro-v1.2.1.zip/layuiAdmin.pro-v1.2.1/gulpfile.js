var gulp = require("gulp");//引入本地安装的 gulp模块
gulp.task("default",function(){//default 为默认任务名，这种情况只需要在命令行中输入 gulp即可。 如果有特定的taskName,需要在命令行中实行 gulp taskName
  console.log("hi, gulp")
})
